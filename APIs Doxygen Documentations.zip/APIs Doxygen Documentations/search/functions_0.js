var searchData=
[
  ['app_5finit_124',['APP_init',['../_app_8c.html#a72f08d66d0b37cf7c4d539fbc2e2ce10',1,'App.c']]],
  ['app_5freceivefcn_125',['APP_receiveFcn',['../_app_8c.html#a1dc413d5cb8f771419ff0a0cdf752e38',1,'App.c']]],
  ['app_5fsendtask_126',['APP_sendTask',['../_app_8c.html#a477966045092c7d9e053b3d5e16aa556',1,'App.c']]]
];
