var searchData=
[
  ['task_78',['Task',['../struct_task.html',1,'']]]
];
