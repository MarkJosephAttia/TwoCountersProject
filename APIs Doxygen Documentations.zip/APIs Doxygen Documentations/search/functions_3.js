var searchData=
[
  ['hrcc_5fenportclock_138',['HRcc_EnPortClock',['../_h_rcc_8h.html#add4385f1e2540afd28c85ec5b5994fa2',1,'HRcc.c']]],
  ['hrcc_5fsystemclockinit_139',['HRcc_SystemClockInit',['../_h_rcc_8h.html#aa80c50e23a75be7fbef7cca383664a8e',1,'HRcc.c']]]
];
