var indexSectionsWithContent =
{
  0: "acdfghlmnrstu",
  1: "cdfghlnrstu",
  2: "acghlmnrsu",
  3: "acghlnrsu",
  4: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Macros"
};

