var searchData=
[
  ['gpio_5finitpins_169',['Gpio_InitPins',['../_gpio_8h.html#ace3432d346abe137b2fbb96a623767b4',1,'Gpio_InitPins(gpio_t *gpio):&#160;Gpio.c'],['../_gpio_8c.html#ace3432d346abe137b2fbb96a623767b4',1,'Gpio_InitPins(gpio_t *gpio):&#160;Gpio.c']]],
  ['gpio_5freadpin_170',['Gpio_ReadPin',['../_gpio_8h.html#a994a1ce90f2bfca8b1fb81a28ff094eb',1,'Gpio_ReadPin(uint32_t port, uint32_t pin, uint8_t *state):&#160;Gpio.c'],['../_gpio_8c.html#a994a1ce90f2bfca8b1fb81a28ff094eb',1,'Gpio_ReadPin(uint32_t port, uint32_t pin, uint8_t *state):&#160;Gpio.c']]],
  ['gpio_5fwritepin_171',['Gpio_WritePin',['../_gpio_8h.html#a2999cf8e39c3dd2a8a0980874223f4d6',1,'Gpio_WritePin(uint32_t port, uint32_t pin, uint32_t pinStatus):&#160;Gpio.c'],['../_gpio_8c.html#a2999cf8e39c3dd2a8a0980874223f4d6',1,'Gpio_WritePin(uint32_t port, uint32_t pin, uint32_t pinStatus):&#160;Gpio.c']]]
];
