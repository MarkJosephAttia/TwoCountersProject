var searchData=
[
  ['app_5finit_158',['APP_init',['../_app_8h.html#ab8f116a6421a2b67b78bcd3bbe23492f',1,'APP_init(void):&#160;App.c'],['../_app_8c.html#ab8f116a6421a2b67b78bcd3bbe23492f',1,'APP_init(void):&#160;App.c']]],
  ['app_5freceivefcn_159',['APP_receiveFcn',['../_app_8h.html#a1dc413d5cb8f771419ff0a0cdf752e38',1,'APP_receiveFcn(void):&#160;App.c'],['../_app_8c.html#a1dc413d5cb8f771419ff0a0cdf752e38',1,'APP_receiveFcn(void):&#160;App.c']]],
  ['app_5fsendtask_160',['APP_sendTask',['../_app_8h.html#a477966045092c7d9e053b3d5e16aa556',1,'APP_sendTask(void):&#160;App.c'],['../_app_8c.html#a477966045092c7d9e053b3d5e16aa556',1,'APP_sendTask(void):&#160;App.c']]]
];
