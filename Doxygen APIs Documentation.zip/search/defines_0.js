var searchData=
[
  ['nvic_5fdisable_223',['NVIC_DISABLE',['../_n_v_i_c_8h.html#a0337ae7a0cecb47b97ce4b648c88fcfb',1,'NVIC.h']]],
  ['nvic_5firqnum_5fwwdg_224',['NVIC_IRQNUM_WWDG',['../_n_v_i_c_8h.html#a56ecf0dabbb9f7e0a3c7da641f70d63c',1,'NVIC.h']]],
  ['nvic_5freset_225',['NVIC_RESET',['../_n_v_i_c_8h.html#ab165ac205c3a11473268b7c5649879f1',1,'NVIC.h']]]
];
